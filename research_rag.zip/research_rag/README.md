# Local Research Paper RAG System

A completely local research-paper analysis system for storing, indexing, and analyzing research papers.

## Features

- **Automatic Paper Detection**: Only processes new papers, avoiding redundant analysis
- **Lightweight Master Index**: Fast paper listing and detection
- **Detailed Paper Analysis**: Extracts methodology, findings, limitations, etc.
- **Question Answering**: Ask questions about your paper collection
- **Research Gap Detection**: Identify gaps across papers
- **Persistent Storage**: All data saved as JSON and DOCX
- **Local LLM Support**: Works with Ollama or other local LLMs

## Installation

```bash
pip install -r requirements.txt
```

## Configuration

Edit `.env` file to configure your local LLM:

```
LLM_API_BASE=http://localhost:11434/v1
LLM_MODEL=llama3.2
```

## Usage

### Process New Papers

```bash
python app.py process
```

This will:
- Detect new PDFs in `research_papers/`
- Analyze only new papers
- Save detailed analysis to `saved/paper_info/`
- Update master index
- Create embeddings for retrieval

### Ask Questions

```bash
python app.py ask --question "What methodologies are commonly used?"
```

### Find Research Gaps

```bash
python app.py gaps
```

### List Papers

```bash
python app.py list
```

## Project Structure

```
research_rag/
├── research_papers/          # Place PDFs here
│   └── saved/               # All generated data
│       ├── master_papers.json
│       ├── paper_info/
│       ├── questions/
│       ├── gaps/
│       ├── documents/
│       └── database/
├── src/
│   ├── stage1/              # Paper processing
│   ├── stage2/              # Retrieval & QA
│   ├── stage3/              # Gap detection
│   ├── stage4/              # Output generation
│   └── utils/
└── app.py
```

## Design Principles

1. **Process once, store permanently**: Papers are analyzed once and stored
2. **No re-analysis**: Existing papers are never reprocessed unless changed
3. **Lightweight master index**: Fast loading with minimal data
4. **Separate detailed storage**: Full analysis in individual JSON files
5. **Explicit gap analysis**: Gaps only when requested, not automatic
