from openai import OpenAI
from typing import List, Dict
from ..config import Config

class GapDetector:
    def __init__(self):
        self.client = OpenAI(
            base_url=Config.LLM_API_BASE,
            api_key=Config.LLM_API_KEY
        )
        self.model = Config.LLM_MODEL
        
        self.categories = [
            "Methodological", "Dataset", "Population", "Geographic",
            "Temporal", "Theoretical", "Evaluation", "Contradiction",
            "Reproducibility", "Research-design", "Application", "Validation"
        ]
    
    def detect_gaps(self, paper_info: List[Dict], comparison: Dict) -> List[Dict]:
        gaps = []
        
        for category in self.categories:
            category_gaps = self._detect_category_gaps(category, paper_info, comparison)
            gaps.extend(category_gaps)
        
        return gaps
    
    def _detect_category_gaps(self, category: str, paper_info: List[Dict], comparison: Dict) -> List[Dict]:
        summary = self._create_summary(paper_info, comparison)
        
        prompt = f"""Identify {category.lower()} gaps in this research collection.

{summary}

Return a JSON list of gaps with:
{{
    "gaps": [
        {{
            "description": "gap description",
            "reasoning": "why this is a gap",
            "supporting_papers": ["paper_id1", "paper_id2"],
            "confidence": 0.8,
            "novelty_score": 7,
            "importance_score": 8,
            "feasibility_score": 7,
            "possible_research_question": "question",
            "possible_objective": "objective",
            "possible_contribution": "contribution"
        }}
    ]
}}
"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.5
            )
            
            import json
            content = response.choices[0].message.content
            content = content.replace('```json', '').replace('```', '').strip()
            result = json.loads(content)
            
            gaps = []
            for i, gap in enumerate(result.get("gaps", [])):
                gap["gap_id"] = f"GAP_{category}_{i+1}"
                gap["category"] = category
                gap["evidence"] = []
                gap["overall_score"] = (gap.get("confidence", 0) * 10 + gap.get("novelty_score", 0) + 
                                       gap.get("importance_score", 0) + gap.get("feasibility_score", 0)) / 4
                gaps.append(gap)
            
            return gaps
        except Exception as e:
            print(f"Gap detection error for {category}: {e}")
            return []
    
    def _create_summary(self, paper_info: List[Dict], comparison: Dict) -> str:
        summary = "Research Papers:\n"
        for p in paper_info:
            summary += f"- {p['basic_info']['title']}: {p.get('research_problem', 'N/A')}\n"
        
        summary += "\nMethodologies:\n"
        for pid, meth in comparison.get("methodologies", {}).items():
            summary += f"- {pid}: {meth[:100]}...\n"
        
        return summary
