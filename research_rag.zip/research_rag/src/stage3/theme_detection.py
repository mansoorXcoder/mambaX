from typing import List, Dict

class ThemeDetection:
    @staticmethod
    def detect_themes(paper_info: List[Dict]) -> List[str]:
        all_keywords = []
        for paper in paper_info:
            all_keywords.extend(paper.get("keywords", []))
        
        from collections import Counter
        counts = Counter(all_keywords)
        return [kw for kw, count in counts.most_common(10) if count > 1]
