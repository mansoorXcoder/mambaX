from openai import OpenAI
from typing import List, Dict
from ..config import Config

class ContradictionDetection:
    def __init__(self):
        self.client = OpenAI(
            base_url=Config.LLM_API_BASE,
            api_key=Config.LLM_API_KEY
        )
        self.model = Config.LLM_MODEL
    
    def detect_contradictions(self, paper_info: List[Dict]) -> List[Dict]:
        contradictions = []
        
        for i, p1 in enumerate(paper_info):
            for p2 in paper_info[i+1:]:
                if self._check_contradiction(p1, p2):
                    contradictions.append({
                        "paper1": p1["paper_id"],
                        "paper2": p2["paper_id"],
                        "area": "findings"
                    })
        
        return contradictions
    
    def _check_contradiction(self, p1: Dict, p2: Dict) -> bool:
        findings1 = " ".join(p1.get("main_findings", []))
        findings2 = " ".join(p2.get("main_findings", []))
        
        if not findings1 or not findings2:
            return False
        
        prompt = f"""Do these findings contradict each other?
Paper 1 findings: {findings1}
Paper 2 findings: {findings2}

Answer with just 'yes' or 'no'."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1
            )
            return "yes" in response.choices[0].message.content.lower()
        except:
            return False
