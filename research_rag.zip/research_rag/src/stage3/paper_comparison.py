from typing import List, Dict

class PaperComparison:
    @staticmethod
    def compare_papers(paper_info: List[Dict]) -> Dict:
        methodologies = {}
        datasets = {}
        themes = {}
        
        for paper in paper_info:
            meth = paper.get("methodology", "")
            if meth:
                methodologies[paper["paper_id"]] = meth
            
            ds = paper.get("dataset", "")
            if ds:
                datasets[paper["paper_id"]] = ds
            
            for kw in paper.get("keywords", []):
                if kw not in themes:
                    themes[kw] = []
                themes[kw].append(paper["paper_id"])
        
        return {
            "methodologies": methodologies,
            "datasets": datasets,
            "themes": themes
        }
