from typing import List, Dict

class GapVerifier:
    @staticmethod
    def verify_gaps(gaps: List[Dict], paper_info: List[Dict]) -> List[Dict]:
        verified = []
        
        for gap in gaps:
            supporting = gap.get("supporting_papers", [])
            if len(supporting) >= 2:
                gap["verified"] = True
                gap["gap_type"] = "inferred"
            elif len(supporting) == 1:
                gap["verified"] = True
                gap["gap_type"] = "explicit"
            else:
                gap["verified"] = False
                gap["gap_type"] = "unverified"
            
            verified.append(gap)
        
        return verified
