from typing import Dict, List
from ..utils.file_utils import load_json, save_json
from ..config import Config

class MasterIndex:
    def __init__(self):
        self.master_file = Config.MASTER_PAPERS_FILE
    
    def load_master_index(self) -> Dict:
        return load_json(self.master_file) or {"papers": []}
    
    def update_master_index(self, paper_info: Dict) -> None:
        master = self.load_master_index()
        
        existing_idx = None
        for i, p in enumerate(master["papers"]):
            if p["paper_id"] == paper_info["paper_id"]:
                existing_idx = i
                break
        
        entry = {
            "paper_id": paper_info["paper_id"],
            "filename": paper_info["source"]["filename"],
            "title": paper_info["basic_info"]["title"],
            "authors": paper_info["basic_info"]["authors"],
            "year": paper_info["basic_info"]["year"],
            "processed": True,
            "processed_at": paper_info.get("processed_at", ""),
            "file_hash": paper_info.get("file_hash", "")
        }
        
        if existing_idx is not None:
            master["papers"][existing_idx] = entry
        else:
            master["papers"].append(entry)
        
        save_json(self.master_file, master)
