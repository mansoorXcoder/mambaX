import re
from typing import Dict, List

class MetadataExtractor:
    @staticmethod
    def extract_metadata(text: str, pdf_metadata: Dict) -> Dict:
        title = pdf_metadata.get("/Title", "")
        if not title:
            title_match = re.search(r'(?:Title|TITLE)[:\s]+([^\n]+)', text[:500])
            title = title_match.group(1).strip() if title_match else ""
        
        author_match = re.search(r'(?:Author|AUTHOR|Authors|AUTHORS)[:\s]+([^\n]+)', text[:1000])
        authors = [a.strip() for a in author_match.group(1).split(",")] if author_match else []
        
        year_match = re.search(r'\b(19|20)\d{2}\b', text[:500])
        year = int(year_match.group()) if year_match else None
        
        return {
            "title": title,
            "authors": authors,
            "year": year
        }
