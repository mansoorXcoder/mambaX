from openai import OpenAI
from typing import Dict
from ..config import Config

class PaperAnalyzer:
    def __init__(self):
        self.client = OpenAI(
            base_url=Config.LLM_API_BASE,
            api_key=Config.LLM_API_KEY
        )
        self.model = Config.LLM_MODEL
    
    def analyze_paper(self, text: str, metadata: Dict) -> Dict:
        prompt = f"""Analyze this research paper and extract the following information in JSON format:
{{
    "research_problem": "brief description",
    "research_question": "main question addressed",
    "objectives": ["obj1", "obj2"],
    "methodology": "description",
    "dataset": "description",
    "population": "description",
    "sample_size": "description",
    "variables": ["var1", "var2"],
    "models": ["model1"],
    "main_findings": ["finding1", "finding2"],
    "contributions": ["contribution1"],
    "limitations": ["limitation1"],
    "future_work": ["future1"],
    "keywords": ["keyword1", "keyword2"]
}}

Paper Title: {metadata.get('title', 'N/A')}
Authors: {', '.join(metadata.get('authors', []))}
Year: {metadata.get('year', 'N/A')}

Full Text:
{text[:15000]}
"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3
            )
            
            import json
            content = response.choices[0].message.content
            content = content.replace('```json', '').replace('```', '').strip()
            analysis = json.loads(content)
            
            return {
                "basic_info": metadata,
                **analysis
            }
        except Exception as e:
            print(f"LLM Analysis error: {e}")
            return {
                "basic_info": metadata,
                "research_problem": "",
                "research_question": "",
                "objectives": [],
                "methodology": "",
                "dataset": "",
                "population": "",
                "sample_size": "",
                "variables": [],
                "models": [],
                "main_findings": [],
                "contributions": [],
                "limitations": [],
                "future_work": [],
                "keywords": []
            }
