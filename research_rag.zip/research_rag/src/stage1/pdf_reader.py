from pypdf import PdfReader
from typing import Dict

class PDFReader:
    @staticmethod
    def read_pdf(filepath: str) -> Dict:
        reader = PdfReader(filepath)
        text = ""
        for page in reader.pages:
            text += page.extract_text() + "\n"
        
        return {
            "text": text,
            "pages": len(reader.pages),
            "metadata": reader.metadata
        }
