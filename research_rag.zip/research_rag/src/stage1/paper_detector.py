import os
from typing import List, Dict, Tuple
from ..utils.file_utils import list_pdf_files, compute_file_hash, load_json, generate_paper_id
from ..config import Config

class PaperDetector:
    def __init__(self):
        self.papers_dir = Config.PAPERS_DIR
        self.master_file = Config.MASTER_PAPERS_FILE
    
    def detect_new_papers(self) -> Tuple[List[Dict], List[str]]:
        current_pdfs = list_pdf_files(self.papers_dir)
        master_data = load_json(self.master_file) or {"papers": []}
        
        existing_papers = {p["filename"]: p for p in master_data["papers"]}
        new_papers = []
        
        for pdf in current_pdfs:
            pdf_path = os.path.join(self.papers_dir, pdf)
            file_hash = compute_file_hash(pdf_path)
            
            if pdf not in existing_papers:
                paper_id = generate_paper_id(pdf, file_hash)
                new_papers.append({
                    "filename": pdf,
                    "paper_id": paper_id,
                    "file_hash": file_hash,
                    "filepath": pdf_path
                })
            elif existing_papers[pdf].get("file_hash") != file_hash:
                paper_id = generate_paper_id(pdf, file_hash)
                new_papers.append({
                    "filename": pdf,
                    "paper_id": paper_id,
                    "file_hash": file_hash,
                    "filepath": pdf_path,
                    "changed": True
                })
        
        return new_papers, current_pdfs
