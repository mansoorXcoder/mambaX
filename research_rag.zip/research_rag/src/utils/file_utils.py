import hashlib
import json
import os
from typing import Dict, List, Optional

def compute_file_hash(filepath: str) -> str:
    with open(filepath, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()

def load_json(filepath: str) -> Optional[Dict]:
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None

def save_json(filepath: str, data: Dict) -> None:
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def list_pdf_files(directory: str) -> List[str]:
    return [f for f in os.listdir(directory) if f.endswith('.pdf')]

def generate_paper_id(filename: str, file_hash: str) -> str:
    clean_name = filename.replace('.pdf', '').replace(' ', '_').lower()
    return f"{clean_name}_{file_hash[:8]}"
