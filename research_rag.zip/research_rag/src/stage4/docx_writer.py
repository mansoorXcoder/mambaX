from docx import Document
from docx.shared import Pt
from datetime import datetime
import os
from typing import Dict
from ..config import Config

class DOCXWriter:
    def __init__(self):
        self.paper_analysis_dir = os.path.join(Config.DOCUMENTS_DIR, "paper_analysis")
        self.question_analysis_dir = os.path.join(Config.DOCUMENTS_DIR, "question_analysis")
        self.gap_analysis_dir = os.path.join(Config.DOCUMENTS_DIR, "gap_analysis")
    
    def save_paper_analysis(self, paper_info: Dict) -> str:
        doc = Document()
        doc.add_heading(paper_info["basic_info"]["title"], 0)
        
        doc.add_heading("Basic Information", level=1)
        doc.add_paragraph(f"Authors: {', '.join(paper_info['basic_info']['authors'])}")
        doc.add_paragraph(f"Year: {paper_info['basic_info']['year']}")
        
        doc.add_heading("Research Problem", level=1)
        doc.add_paragraph(paper_info.get("research_problem", "N/A"))
        
        doc.add_heading("Research Question", level=1)
        doc.add_paragraph(paper_info.get("research_question", "N/A"))
        
        doc.add_heading("Methodology", level=1)
        doc.add_paragraph(paper_info.get("methodology", "N/A"))
        
        doc.add_heading("Main Findings", level=1)
        for finding in paper_info.get("main_findings", []):
            doc.add_paragraph(finding, style="List Bullet")
        
        doc.add_heading("Limitations", level=1)
        for limit in paper_info.get("limitations", []):
            doc.add_paragraph(limit, style="List Bullet")
        
        filepath = os.path.join(self.paper_analysis_dir, f"{paper_info['paper_id']}.docx")
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        doc.save(filepath)
        return filepath
    
    def save_question_analysis(self, question: str, answer_data: Dict) -> str:
        doc = Document()
        doc.add_heading("Question Analysis", 0)
        
        doc.add_heading("Question", level=1)
        doc.add_paragraph(question)
        
        doc.add_heading("Answer", level=1)
        doc.add_paragraph(answer_data.get("answer", ""))
        
        doc.add_heading("Supporting Papers", level=1)
        for paper_id in answer_data.get("supporting_papers", []):
            doc.add_paragraph(paper_id, style="List Bullet")
        
        filepath = os.path.join(self.question_analysis_dir, f"{answer_data['question_id']}.docx")
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        doc.save(filepath)
        return filepath
    
    def save_gap_analysis(self, gaps: list) -> str:
        doc = Document()
        doc.add_heading("Research Gap Analysis", 0)
        
        for gap in gaps:
            doc.add_heading(f"{gap['gap_id']} - {gap['category']}", level=2)
            doc.add_paragraph(f"Description: {gap.get('description', '')}")
            doc.add_paragraph(f"Reasoning: {gap.get('reasoning', '')}")
            doc.add_paragraph(f"Confidence: {gap.get('confidence', 0)}")
            doc.add_paragraph(f"Overall Score: {gap.get('overall_score', 0)}")
            doc.add_paragraph(f"Type: {gap.get('gap_type', '')}")
        
        filepath = os.path.join(self.gap_analysis_dir, f"gap_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx")
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        doc.save(filepath)
        return filepath
