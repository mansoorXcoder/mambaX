from typing import List, Dict

class ReportGenerator:
    @staticmethod
    def generate_summary(paper_info: List[Dict]) -> str:
        summary = f"Research Collection Summary\n"
        summary += f"Total Papers: {len(paper_info)}\n\n"
        
        for paper in paper_info:
            summary += f"- {paper['basic_info']['title']} ({paper['basic_info']['year']})\n"
        
        return summary
