import json
import os
from datetime import datetime
from typing import Dict
from ..config import Config
from ..utils.file_utils import save_json

class JSONWriter:
    def __init__(self):
        self.paper_info_dir = Config.PAPER_INFO_DIR
        self.questions_dir = Config.QUESTIONS_DIR
        self.gaps_dir = Config.GAPS_DIR
    
    def save_paper_info(self, paper_info: Dict) -> str:
        filepath = os.path.join(self.paper_info_dir, f"{paper_info['paper_id']}.json")
        save_json(filepath, paper_info)
        return filepath
    
    def save_question(self, question: str, answer: Dict) -> str:
        question_id = f"question_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        data = {
            "question_id": question_id,
            "question": question,
            "answer": answer.get("answer", ""),
            "supporting_papers": answer.get("supporting_papers", []),
            "citations": answer.get("citations", []),
            "created_at": datetime.now().isoformat(),
            "model": Config.LLM_MODEL
        }
        filepath = os.path.join(self.questions_dir, f"{question_id}.json")
        save_json(filepath, data)
        return filepath
    
    def save_gaps(self, gaps: list) -> str:
        gap_id = f"gap_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        data = {
            "gap_analysis_id": gap_id,
            "gaps": gaps,
            "created_at": datetime.now().isoformat(),
            "total_gaps": len(gaps)
        }
        filepath = os.path.join(self.gaps_dir, f"{gap_id}.json")
        save_json(filepath, data)
        return filepath
