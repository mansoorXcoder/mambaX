import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    LLM_API_BASE = os.getenv("LLM_API_BASE", "http://localhost:11434/v1")
    LLM_MODEL = os.getenv("LLM_MODEL", "llama3.2")
    LLM_API_KEY = os.getenv("LLM_API_KEY", "not-needed")
    EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    
    PAPERS_DIR = os.path.join(os.path.dirname(__file__), "..", "research_papers")
    SAVED_DIR = os.path.join(os.path.dirname(__file__), "..", "research_papers", "saved")
    
    MASTER_PAPERS_FILE = os.path.join(SAVED_DIR, "master_papers.json")
    PAPER_INFO_DIR = os.path.join(SAVED_DIR, "paper_info")
    QUESTIONS_DIR = os.path.join(SAVED_DIR, "questions")
    GAPS_DIR = os.path.join(SAVED_DIR, "gaps")
    DOCUMENTS_DIR = os.path.join(SAVED_DIR, "documents")
    VECTOR_DB_DIR = os.path.join(SAVED_DIR, "database", "vector_database")
    LOGS_DIR = os.path.join(SAVED_DIR, "logs")
    
    CHUNK_SIZE = 500
    CHUNK_OVERLAP = 50
    TOP_K_RETRIEVAL = 5
