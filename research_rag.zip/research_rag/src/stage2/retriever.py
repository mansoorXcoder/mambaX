from typing import List, Dict
from .embeddings import Embeddings
from .vector_db import VectorDB
from ..config import Config

class Retriever:
    def __init__(self):
        self.embeddings = Embeddings()
        self.vector_db = VectorDB()
        self.top_k = Config.TOP_K_RETRIEVAL
    
    def retrieve(self, query: str) -> List[Dict]:
        query_emb = self.embeddings.create_embeddings([query])[0]
        results = self.vector_db.search(query_emb, self.top_k)
        return results
