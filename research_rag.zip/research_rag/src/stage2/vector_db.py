import faiss
import pickle
import os
from typing import List, Dict, Tuple
from ..config import Config

class VectorDB:
    def __init__(self):
        self.db_dir = Config.VECTOR_DB_DIR
        self.index_file = os.path.join(self.db_dir, "faiss.index")
        self.metadata_file = os.path.join(self.db_dir, "metadata.pkl")
        self.index = None
        self.metadata = []
        self._load()
    
    def _load(self):
        if os.path.exists(self.index_file):
            self.index = faiss.read_index(self.index_file)
        else:
            self.index = faiss.IndexFlatL2(384)
        
        if os.path.exists(self.metadata_file):
            with open(self.metadata_file, 'rb') as f:
                self.metadata = pickle.load(f)
    
    def add_chunks(self, embeddings: List[List[float]], chunk_data: List[Dict]) -> None:
        if not embeddings:
            return
        
        import numpy as np
        emb_array = np.array(embeddings, dtype='float32')
        self.index.add(emb_array)
        self.metadata.extend(chunk_data)
        self._save()
    
    def _save(self):
        os.makedirs(self.db_dir, exist_ok=True)
        faiss.write_index(self.index, self.index_file)
        with open(self.metadata_file, 'wb') as f:
            pickle.dump(self.metadata, f)
    
    def search(self, query_embedding: List[float], k: int = 5) -> List[Dict]:
        import numpy as np
        query_array = np.array([query_embedding], dtype='float32')
        distances, indices = self.index.search(query_array, k)
        
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < len(self.metadata):
                results.append({
                    "metadata": self.metadata[idx],
                    "distance": float(dist)
                })
        
        return results
