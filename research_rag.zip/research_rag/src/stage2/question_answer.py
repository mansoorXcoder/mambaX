from openai import OpenAI
from typing import Dict, List
from ..config import Config

class QuestionAnswer:
    def __init__(self):
        self.client = OpenAI(
            base_url=Config.LLM_API_BASE,
            api_key=Config.LLM_API_KEY
        )
        self.model = Config.LLM_MODEL
    
    def answer_question(self, question: str, context: List[Dict], paper_info: List[Dict]) -> Dict:
        context_text = "\n\n".join([
            f"From {r['metadata']['paper_id']}: {r['metadata']['text']}" 
            for r in context[:5]
        ])
        
        paper_summaries = "\n\n".join([
            f"{p['basic_info']['title']} by {', '.join(p['basic_info']['authors'])} ({p['basic_info']['year']})"
            for p in paper_info
        ])
        
        prompt = f"""Answer the following question based on the provided research papers.

Available Papers:
{paper_summaries}

Relevant Context:
{context_text}

Question: {question}

Provide a comprehensive answer with citations to specific papers. Format your response as:
{{
    "answer": "your answer",
    "supporting_papers": ["paper_id1", "paper_id2"],
    "citations": [{{"paper_id": "paper_id1", "page": 1, "section": "Introduction"}}]
}}
"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3
            )
            
            import json
            content = response.choices[0].message.content
            content = content.replace('```json', '').replace('```', '').strip()
            result = json.loads(content)
            
            return result
        except Exception as e:
            print(f"QA error: {e}")
            return {
                "answer": f"Error processing question: {str(e)}",
                "supporting_papers": [],
                "citations": []
            }
