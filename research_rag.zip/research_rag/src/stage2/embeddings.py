from sentence_transformers import SentenceTransformer
from typing import List
import numpy as np
from ..config import Config

class Embeddings:
    def __init__(self):
        self.model = SentenceTransformer(Config.EMBEDDING_MODEL)
    
    def create_embeddings(self, texts: List[str]) -> List[List[float]]:
        embeddings = self.model.encode(texts, show_progress_bar=False)
        return embeddings.tolist()
