from ..utils.text_utils import chunk_text, clean_text
from ..config import Config

class Chunker:
    def __init__(self):
        self.chunk_size = Config.CHUNK_SIZE
        self.overlap = Config.CHUNK_OVERLAP
    
    def chunk_paper(self, text: str, paper_id: str) -> list:
        clean = clean_text(text)
        chunks = chunk_text(clean, self.chunk_size, self.overlap)
        
        chunk_data = []
        for i, chunk in enumerate(chunks):
            chunk_data.append({
                "chunk_id": f"{paper_id}_chunk_{i}",
                "paper_id": paper_id,
                "text": chunk,
                "index": i
            })
        
        return chunk_data
