import sys
import os
from datetime import datetime
import shutil

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.config import Config
from src.stage1.paper_detector import PaperDetector
from src.stage1.pdf_reader import PDFReader
from src.stage1.metadata_extractor import MetadataExtractor
from src.stage1.paper_analyzer import PaperAnalyzer
from src.stage1.master_index import MasterIndex
from src.stage2.chunker import Chunker
from src.stage2.embeddings import Embeddings
from src.stage2.vector_db import VectorDB
from src.stage2.retriever import Retriever
from src.stage2.question_answer import QuestionAnswer
from src.stage3.paper_comparison import PaperComparison
from src.stage3.theme_detection import ThemeDetection
from src.stage3.contradiction_detection import ContradictionDetection
from src.stage3.gap_detector import GapDetector
from src.stage3.gap_verifier import GapVerifier
from src.stage4.json_writer import JSONWriter
from src.stage4.docx_writer import DOCXWriter
from src.stage4.report_generator import ReportGenerator
from src.utils.file_utils import load_json, list_pdf_files

class ResearchRAG:
    def __init__(self):
        self.config = Config
        self.json_writer = JSONWriter()
        self.docx_writer = DOCXWriter()
    
    def process_new_papers(self):
        print("Detecting new papers...")
        detector = PaperDetector()
        new_papers, current_pdfs = detector.detect_new_papers()
        
        if not new_papers:
            print("No new papers found.")
            return
        
        print(f"Found {len(new_papers)} new papers to process.")
        
        pdf_reader = PDFReader()
        metadata_extractor = MetadataExtractor()
        paper_analyzer = PaperAnalyzer()
        master_index = MasterIndex()
        chunker = Chunker()
        embeddings = Embeddings()
        vector_db = VectorDB()
        
        for paper in new_papers:
            print(f"Processing: {paper['filename']}")
            
            pdf_data = pdf_reader.read_pdf(paper['filepath'])
            metadata = metadata_extractor.extract_metadata(pdf_data['text'], pdf_data['metadata'])
            analysis = paper_analyzer.analyze_paper(pdf_data['text'], metadata)
            
            paper_info = {
                "paper_id": paper['paper_id'],
                "file_hash": paper['file_hash'],
                "processed_at": datetime.now().isoformat(),
                "source": {
                    "filename": paper['filename'],
                    "pages": pdf_data['pages']
                },
                **analysis
            }
            
            self.json_writer.save_paper_info(paper_info)
            self.docx_writer.save_paper_analysis(paper_info)
            master_index.update_master_index(paper_info)
            
            chunks = chunker.chunk_paper(pdf_data['text'], paper['paper_id'])
            chunk_texts = [c['text'] for c in chunks]
            chunk_embeddings = embeddings.create_embeddings(chunk_texts)
            vector_db.add_chunks(chunk_embeddings, chunks)
            
            print(f"  - Analyzed and saved: {paper['paper_id']}")
        
        print(f"Processed {len(new_papers)} papers successfully.")
    
    def ask_question(self, question: str):
        print(f"Processing question: {question}")
        
        master_data = load_json(self.config.MASTER_PAPERS_FILE)
        if not master_data or not master_data.get("papers"):
            print("No papers in database. Process papers first.")
            return
        
        paper_info_dir = self.config.PAPER_INFO_DIR
        paper_info_list = []
        
        for paper_entry in master_data["papers"]:
            paper_file = os.path.join(paper_info_dir, f"{paper_entry['paper_id']}.json")
            if os.path.exists(paper_file):
                paper_data = load_json(paper_file)
                if paper_data:
                    paper_info_list.append(paper_data)
        
        if not paper_info_list:
            print("No detailed paper info found.")
            return
        
        retriever = Retriever()
        qa = QuestionAnswer()
        
        context = retriever.retrieve(question)
        answer = qa.answer_question(question, context, paper_info_list)
        
        json_path = self.json_writer.save_question(question, answer)
        docx_path = self.docx_writer.save_question_analysis(question, answer)
        
        print(f"\nAnswer: {answer.get('answer', '')}")
        print(f"Supporting papers: {answer.get('supporting_papers', [])}")
        print(f"\nSaved to: {json_path}")
        print(f"Document: {docx_path}")
    
    def find_gaps(self):
        print("Analyzing research gaps...")
        
        master_data = load_json(self.config.MASTER_PAPERS_FILE)
        if not master_data or not master_data.get("papers"):
            print("No papers in database.")
            return
        
        paper_info_dir = self.config.PAPER_INFO_DIR
        paper_info_list = []
        
        for paper_entry in master_data["papers"]:
            paper_file = os.path.join(paper_info_dir, f"{paper_entry['paper_id']}.json")
            if os.path.exists(paper_file):
                paper_data = load_json(paper_file)
                if paper_data:
                    paper_info_list.append(paper_data)
        
        if len(paper_info_list) < 2:
            print("Need at least 2 papers for gap analysis.")
            return
        
        comparison = PaperComparison.compare_papers(paper_info_list)
        gap_detector = GapDetector()
        gap_verifier = GapVerifier()
        
        gaps = gap_detector.detect_gaps(paper_info_list, comparison)
        verified_gaps = gap_verifier.verify_gaps(gaps, paper_info_list)
        
        json_path = self.json_writer.save_gaps(verified_gaps)
        docx_path = self.docx_writer.save_gap_analysis(verified_gaps)
        
        print(f"Found {len(verified_gaps)} research gaps.")
        for gap in verified_gaps[:5]:
            print(f"  - {gap['gap_id']}: {gap['category']} - {gap.get('description', '')[:60]}...")
        
        print(f"\nSaved to: {json_path}")
        print(f"Document: {docx_path}")
    
    def list_papers(self):
        master_data = load_json(self.config.MASTER_PAPERS_FILE)
        if not master_data or not master_data.get("papers"):
            print("No papers in database.")
            return
        
        print(f"\nTotal Papers: {len(master_data['papers'])}\n")
        for paper in master_data['papers']:
            print(f"- {paper['title']} ({paper['year']})")
            print(f"  ID: {paper['paper_id']}")
            print(f"  Authors: {', '.join(paper['authors'])}")
            print()

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Local Research Paper RAG System")
    parser.add_argument("command", choices=["process", "ask", "gaps", "list"], help="Command to run")
    parser.add_argument("--question", "-q", help="Question to ask")
    
    args = parser.parse_args()
    
    rag = ResearchRAG()
    
    if args.command == "process":
        rag.process_new_papers()
    elif args.command == "ask":
        if not args.question:
            print("Please provide a question with --question")
            return
        rag.ask_question(args.question)
    elif args.command == "gaps":
        rag.find_gaps()
    elif args.command == "list":
        rag.list_papers()

if __name__ == "__main__":
    main()
